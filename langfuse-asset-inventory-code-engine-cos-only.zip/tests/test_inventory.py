import io
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import inventariar_langfuse as inventory
import run_job

BASE = 'https://cloud.langfuse.com'
PROJECT = 'project-example'


def observation(trace, oid, typ, name, parent=None, metadata=None, model=None):
    return {'id': oid, 'traceId': trace, 'projectId': PROJECT, 'type': typ,
            'name': name, 'parentObservationId': parent,
            'startTime': '2026-11-04T08:30:00Z',
            'metadata': metadata or {}, 'model': model}


class FakeBody:
    def __init__(self, content): self.content = content
    def read(self): return self.content


class MissingKeyError(Exception):
    response = {'Error': {'Code': 'NoSuchKey'}}


class FakeCOS:
    def __init__(self):
        self.objects = {}
        self.put_calls = 0
        self.bucket_error = None
        self.read_error = None
    def head_bucket(self, Bucket):
        if self.bucket_error: raise self.bucket_error
    def get_object(self, Bucket, Key):
        if self.read_error: raise self.read_error
        if (Bucket, Key) not in self.objects: raise MissingKeyError()
        return {'Body': FakeBody(self.objects[(Bucket, Key)])}
    def put_object(self, Bucket, Key, Body, ContentType):
        self.put_calls += 1
        self.objects[(Bucket, Key)] = Body


class InventoryTests(unittest.TestCase):
    def test_incremental_discovery_deduplicates(self):
        observations = [
            observation('t1', 'a', 'AGENT', 'HR Policy Assistant', metadata={'agent_id':'hr-agent-1'}),
            observation('t1', 'b', 'TOOL', 'search_hr_policies', 'a', {'tool_id':'search_hr_policies'}),
            observation('t1', 'c', 'RETRIEVER', 'Knowledge lookup', 'b', {
                'knowledge_base_id':'kb-hr-1','knowledge_base_name':'HR Policies Knowledge Base'}),
            observation('t1', 'd', 'GENERATION', 'Answer', 'a', model='granite-3.3-8b-instruct'),
        ]
        catalog = inventory.initial_catalog(BASE, PROJECT)
        first = inventory.discover(catalog, observations, PROJECT, inspect_io=False)
        second = inventory.discover(catalog, observations, PROJECT, inspect_io=False)
        self.assertEqual(first['added']['agents'], 1)
        self.assertEqual(first['added']['tools'], 1)
        self.assertEqual(first['added']['knowledge_bases'], 1)
        self.assertEqual(first['added']['foundation_models'], 1)
        self.assertEqual(sum(second['added'].values()), 0)

    def test_cos_only_requires_all_env(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(ValueError, 'COS_'):
                run_job.read_config()

    def test_cos_roundtrip_first_run_then_merge(self):
        c = FakeCOS()
        key = 'inventario_langfuse.json'
        bucket = 'my-bucket'
        with tempfile.TemporaryDirectory() as d:
            local = Path(d) / 'inventory.json'
            self.assertFalse(run_job.download_inventory(c,bucket,key,local))
            catalog = inventory.initial_catalog(BASE, PROJECT)
            inventory.discover(catalog,[observation('t1','x','AGENT','A')],PROJECT,False)
            inventory.save_atomic(local, catalog)
            run_job.upload_inventory(c,bucket,key,local)
            local.unlink()
            self.assertTrue(run_job.download_inventory(c,bucket,key,local))
            loaded = inventory.load_catalog(local,BASE,PROJECT)
            inventory.discover(loaded,[observation('t1','x','AGENT','A'),
                                       observation('t2','y','AGENT','B')],PROJECT,False)
            inventory.save_atomic(local,loaded)
            run_job.upload_inventory(c,bucket,key,local)
            self.assertEqual(len(json.loads(c.objects[(bucket,key)])['inventory']['agents']), 2)
            self.assertEqual(c.put_calls, 2)

    def test_cos_failure_never_falls_back_to_new_inventory(self):
        c = FakeCOS()
        c.bucket_error = RuntimeError('access denied')
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(RuntimeError, 'access denied'):
                run_job.download_inventory(c,'bucket','key',Path(d)/'inventory.json')
            self.assertEqual(c.put_calls,0)

    def test_invalid_existing_json_is_not_overwritten(self):
        c = FakeCOS()
        c.objects[('bucket','key')] = b'not-json'
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(json.JSONDecodeError):
                run_job.download_inventory(c,'bucket','key',Path(d)/'inventory.json')
            self.assertEqual(c.put_calls,0)

    def test_dry_run_does_not_write_cos(self):
        c = FakeCOS()
        env = {
            'LANGFUSE_BASE_URL':BASE, 'LANGFUSE_PROJECT_ID':PROJECT,
            'LANGFUSE_PUBLIC_KEY':'pk-test', 'LANGFUSE_SECRET_KEY':'sk-test',
            'COS_ENDPOINT':'https://s3.eu-de.cloud-object-storage.appdomain.cloud',
            'COS_API_KEY':'cos-test', 'COS_SERVICE_INSTANCE_ID':'crn-test',
            'COS_BUCKET':'bucket', 'INVENTORY_DRY_RUN':'true',
        }
        def fake_run(path):
            inventory.save_atomic(path, inventory.initial_catalog(BASE,PROJECT))
        with mock.patch.dict(os.environ,env,clear=True), \
             mock.patch.object(run_job,'make_cos_client',return_value=c), \
             mock.patch.object(run_job,'run_inventory',side_effect=fake_run):
            self.assertEqual(run_job.main(),0)
            self.assertEqual(c.put_calls,0)


if __name__=='__main__': unittest.main()
